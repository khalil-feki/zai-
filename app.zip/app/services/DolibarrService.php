<?php
class DolibarrService {
    private $apiUrl;
    private $apiKey;
    private $username;
    private $password;
    private $token;
    private $cacheDir;
    private $cacheExpiry = 3600; // 1 hour

    public function __construct($apiUrl = null, $apiKey = null, $username = null, $password = null) {
        // Use provided parameters or fall back to environment variables
        $this->apiUrl = $apiUrl ?: getenv('DOLIBARR_API_URL');
        $this->apiKey = $apiKey ?: getenv('DOLIBARR_API_KEY');
        $this->username = $username ?: getenv('DOLIBARR_USERNAME');
        $this->password = $password ?: getenv('DOLIBARR_PASSWORD');
        $this->token = null;
        
        // Set up cache directory
        $this->cacheDir = dirname(dirname(dirname(__FILE__))) . '/cache/dolibarr';
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0755, true);
        }
    }

    public function isConnected() {
        // Check if we already have a token
        if ($this->token) {
            return true;
        }
        
        // Try to authenticate
        try {
            return $this->authenticate();
        } catch (Exception $e) {
            return false;
        }
    }

    public function authenticate() {
        $url = $this->apiUrl . '/api/index.php/login';
        
        $data = [
            'login' => $this->username,
            'password' => $this->password,
            'entity' => 1
        ];

        $response = $this->makeRequest('POST', $url, $data);
        
        // Check if the response contains a success object with a token
        if (isset($response['success']) && isset($response['success']['token'])) {
            $this->token = $response['success']['token'];
            return true;
        }
        
        // If we get here, authentication failed
        return false;
    }

    public function getProducts($limit = 10, $offset = 0) {
        $cacheKey = "products_" . $limit . "_" . $offset;
        $cachedData = $this->getCache($cacheKey);
        
        if ($cachedData !== false) {
            return $cachedData;
        }
        
        if (!$this->token) {
            $this->authenticate();
        }
        
        $url = $this->apiUrl . '/api/index.php/products?limit=' . $limit . '&page=' . $offset;
        $response = $this->makeRequest('GET', $url);
        
        if (!isset($response['error'])) {
            $this->setCache($cacheKey, $response);
        }
        
        return $response;
    }

    public function getProduct($id) {
        $cacheKey = "product_" . $id;
        $cachedData = $this->getCache($cacheKey);
        
        if ($cachedData !== false) {
            return $cachedData;
        }
        
        if (!$this->token) {
            $this->authenticate();
        }
        
        $url = $this->apiUrl . '/api/index.php/products/' . $id;
        $response = $this->makeRequest('GET', $url);
        
        if (!isset($response['error'])) {
            $this->setCache($cacheKey, $response);
        }
        
        return $response;
    }
    
    public function getOrders($limit = 10, $offset = 0) {
        $cacheKey = "orders_" . $limit . "_" . $offset;
        $cachedData = $this->getCache($cacheKey);
        
        if ($cachedData !== false) {
            return $cachedData;
        }
        
        if (!$this->token) {
            $this->authenticate();
        }
        
        $url = $this->apiUrl . '/api/index.php/orders?limit=' . $limit . '&page=' . $offset;
        $response = $this->makeRequest('GET', $url);
        
        if (!isset($response['error'])) {
            $this->setCache($cacheKey, $response);
        }
        
        return $response;
    }

    private function makeRequest($method, $url, $data = null) {
        $curl = curl_init();

        $headers = [
            'DOLAPIKEY: ' . $this->apiKey,
            'Content-Type: application/json'
        ];

        if ($this->token) {
            $headers[] = 'Authorization: Bearer ' . $this->token;
        }

        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_SSL_VERIFYPEER => false, // Only for development
        ]);

        if ($data && ($method === 'POST' || $method === 'PUT')) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($curl);
        $err = curl_error($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        curl_close($curl);

        if ($err) {
            return ['error' => $err];
        } else {
            $decodedResponse = json_decode($response, true);
            
            // Handle error responses
            if ($httpCode >= 400) {
                return [
                    'error' => 'HTTP Error ' . $httpCode,
                    'message' => is_array($decodedResponse) ? json_encode($decodedResponse) : $response
                ];
            }
            
            return $decodedResponse;
        }
    }
    
    // Cache methods
    private function getCache($key) {
        $cacheFile = $this->cacheDir . '/' . md5($key) . '.cache';
        
        if (file_exists($cacheFile) && (time() - filemtime($cacheFile) < $this->cacheExpiry)) {
            return json_decode(file_get_contents($cacheFile), true);
        }
        
        return false;
    }
    
    private function setCache($key, $data) {
        $cacheFile = $this->cacheDir . '/' . md5($key) . '.cache';
        file_put_contents($cacheFile, json_encode($data));
    }
}