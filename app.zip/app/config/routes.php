<?php
// Define routes
$router = new Router();

// Home route
$router->addRoute('', 'HomeController', 'index');
$router->addRoute('home', 'HomeController', 'index');

// Auth routes
$router->addRoute('auth/login', 'AuthController', 'login');
$router->addRoute('auth/register', 'AuthController', 'register');
$router->addRoute('auth/logout', 'AuthController', 'logout');

// Product routes
$router->addRoute('products', 'ProductController', 'index');
$router->addRoute('product/view/{id}', 'ProductController', 'view');
$router->addRoute('product/search', 'ProductController', 'search');

// User routes
$router->addRoute('user/profile', 'UserController', 'profile');
$router->addRoute('user/update', 'UserController', 'update');
$router->addRoute('user/orders', 'UserController', 'orders');
$router->addRoute('user/addresses', 'UserController', 'addresses');
$router->addRoute('user/save-address', 'UserController', 'saveAddress');

// Cart routes
$router->addRoute('cart', 'CartController', 'index');
$router->addRoute('cart/add', 'CartController', 'add');
$router->addRoute('cart/update', 'CartController', 'update');
$router->addRoute('cart/remove', 'CartController', 'remove');
$router->addRoute('cart/checkout', 'CartController', 'checkout');

// Category routes
$router->addRoute('category', 'CategoryController', 'index');
$router->addRoute('category/view/{id}', 'CategoryController', 'view');

// Process the request
$router->dispatch();
?>