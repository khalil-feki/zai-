<?php
// Application configuration
define('BASE_URL', 'http://localhost/zai/');
define('APP_ROOT', dirname(dirname(__FILE__)));
define('SITE_NAME', 'ZAI E-Commerce');

// Environment detection
define('ENVIRONMENT', getenv('APP_ENV') ?: 'development');

// Dolibarr API configuration
define('DOLIBARR_API_URL', getenv('DOLIBARR_API_URL') ?: 'https://ecommerce.cieloo.io');
define('DOLIBARR_API_KEY', getenv('DOLIBARR_API_KEY') ?: '');
define('DOLIBARR_USERNAME', getenv('DOLIBARR_USERNAME') ?: 'khalil');
define('DOLIBARR_PASSWORD', getenv('DOLIBARR_PASSWORD') ?: 'khalil123');

// Dolibarr Database configuration
define('DB_HOST', getenv('DB_HOST') ?: 'c137d.myd.infomaniak.com');
define('DB_NAME', getenv('DB_NAME') ?: 'c137d_app_dolibarr_20');
define('DB_USER', getenv('DB_USER') ?: 'c137d_ecom');
define('DB_PASSWORD', getenv('DB_PASSWORD') ?: 'Ecom2024@');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_PREFIX', getenv('DB_PREFIX') ?: 'llx_');

// Cache configuration
define('CACHE_ENABLED', true);
define('CACHE_DIR', dirname(dirname(dirname(__FILE__))) . '/cache');
define('CACHE_EXPIRY', 3600); // 1 hour in seconds

// Error reporting based on environment
if (ENVIRONMENT === 'development') {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
}

// Session configuration
session_start();

// Helper functions
function redirect($page) {
    // Check if the page already has query parameters
    if (strpos($page, '?') === 0) {
        // It's already in the query parameter format
        header('Location: ' . BASE_URL . $page);
    } else {
        // Convert to query parameter format if it's a simple path
        $parts = explode('/', $page);
        
        if (count($parts) >= 2) {
            header('Location: ' . BASE_URL . '?page=' . $parts[0] . '&action=' . $parts[1]);
        } else if (count($parts) == 1 && !empty($parts[0])) {
            header('Location: ' . BASE_URL . '?page=' . $parts[0]);
        } else {
            // Empty page, redirect to home
            header('Location: ' . BASE_URL);
        }
    }
    exit;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Get environment variable with fallback
 * @param string $key Environment variable name
 * @param mixed $default Default value if not found
 * @return mixed
 */
function env($key, $default = null) {
    $value = getenv($key);
    if ($value === false) {
        return $default;
    }
    return $value;
}

/**
 * Create cache directories if they don't exist
 */
function ensureCacheDirectories() {
    if (!is_dir(CACHE_DIR)) {
        mkdir(CACHE_DIR, 0755, true);
    }
    
    $dolibarrCacheDir = CACHE_DIR . '/dolibarr';
    if (!is_dir($dolibarrCacheDir)) {
        mkdir($dolibarrCacheDir, 0755, true);
    }
}

// Ensure cache directories exist
if (CACHE_ENABLED) {
    ensureCacheDirectories();
}
?>