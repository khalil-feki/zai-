<?php
class ErrorHandler {
    public static function handleException($exception) {
        error_log($exception->getMessage());
        
        if (defined('ENVIRONMENT') && ENVIRONMENT === 'development') {
            echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; margin: 10px; border-radius: 4px;'>";
            echo "<h3>Error:</h3>";
            echo "<p>" . $exception->getMessage() . "</p>";
            echo "<pre>" . $exception->getTraceAsString() . "</pre>";
            echo "</div>";
        } else {
            echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; margin: 10px; border-radius: 4px;'>";
            echo "<p>An error occurred. Please try again later.</p>";
            echo "</div>";
        }
    }
}
?>