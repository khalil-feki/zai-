<?php require_once 'app/views/containers/header.php'; ?>

<div class="checkout-container">
    <h1>Checkout</h1>
    
    <div class="checkout-content">
        <div class="order-summary">
            <h2>Order Summary</h2>
            <div class="order-items">
                <?php while ($item = $cartItems->fetch(PDO::FETCH_ASSOC)): ?>
                    <div class="order-item">
                        <div class="item-info">
                            <img src="<?= BASE_URL ?>public/images/products/<?= $item['product_id'] ?>.jpg" 
                                 alt="<?= htmlspecialchars($item['label']) ?>"
                                 onerror="this.src='<?= BASE_URL ?>public/images/no-image.jpg'">
                            <div>
                                <h3><?= htmlspecialchars($item['label']) ?></h3>
                                <p>Quantity: <?= $item['quantity'] ?></p>
                            </div>
                        </div>
                        <div class="item-price">
                            <p>$<?= number_format($item['price'], 2) ?> × <?= $item['quantity'] ?></p>
                            <p class="total">$<?= number_format($item['total_price'], 2) ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
            
            <div class="order-totals">
                <div class="total-row">
                    <span>Subtotal:</span>
                    <span>$<?= number_format($cartTotal, 2) ?></span>
                </div>
                <div class="total-row">
                    <span>Shipping:</span>
                    <span>Free</span>
                </div>
                <div class="total-row grand-total">
                    <span>Total:</span>
                    <span>$<?= number_format($cartTotal, 2) ?></span>
                </div>
            </div>
        </div>
        
        <div class="checkout-form">
            <h2>Shipping Information</h2>
            <form action="<?= BASE_URL ?>checkout/process" method="POST">
                <div class="form-group">
                    <label for="shipping_address">Shipping Address</label>
                    <textarea id="shipping_address" name="shipping_address" rows="4" required></textarea>
                </div>
                
                <div class="form-group checkbox-group">
                    <input type="checkbox" id="same_address" name="same_address" checked>
                    <label for="same_address">Billing address same as shipping</label>
                </div>
                
                <div id="billing_address_container" class="form-group hidden">
                    <label for="billing_address">Billing Address</label>
                    <textarea id="billing_address" name="billing_address" rows="4"></textarea>
                </div>
                
                <h2>Payment Method</h2>
                <div class="payment-methods">
                    <div class="payment-method">
                        <input type="radio" id="payment_cod" name="payment_method" value="cod" checked>
                        <label for="payment_cod">Cash on Delivery</label>
                    </div>
                    
                    <div class="payment-method">
                        <input type="radio" id="payment_bank" name="payment_method" value="bank">
                        <label for="payment_bank">Bank Transfer</label>
                    </div>
                </div>
                
                <div class="form-actions">
                    <a href="<?= BASE_URL ?>cart" class="btn">Back to Cart</a>
                    <button type="submit" class="btn btn-primary">Place Order</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Toggle billing address visibility
    document.getElementById('same_address').addEventListener('change', function() {
        const billingContainer = document.getElementById('billing_address_container');
        if (this.checked) {
            billingContainer.classList.add('hidden');
        } else {
            billingContainer.classList.remove('hidden');
        }
    });
</script>

<?php require_once 'app/views/containers/footer.php'; ?>