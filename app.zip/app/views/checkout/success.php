<?php require_once 'app/views/containers/header.php'; ?>

<div class="order-success-container">
    <div class="success-header">
        <h1>Order Placed Successfully!</h1>
        <p>Thank you for your purchase. Your order has been received and is being processed.</p>
    </div>
    
    <div class="order-details">
        <h2>Order Details</h2>
        <div class="order-info">
            <div class="info-row">
                <span>Order Number:</span>
                <span><?= htmlspecialchars($order['ref']) ?></span>
            </div>
            <div class="info-row">
                <span>Date:</span>
                <span><?= date('F j, Y', strtotime($order['date_commande'])) ?></span>
            </div>
            <div class="info-row">
                <span>Total Amount:</span>
                <span>$<?= number_format($order['total_ht'], 2) ?></span>
            </div>
            <div class="info-row">
                <span>Shipping Address:</span>
                <span><?= nl2br(htmlspecialchars($order['note_private'])) ?></span>
            </div>
        </div>
        
        <h3>Order Items</h3>
        <div class="order-items">
            <?php while ($item = $orderItems->fetch(PDO::FETCH_ASSOC)): ?>
                <div class="order-item">
                    <div class="item-info">
                        <h4><?= htmlspecialchars($item['label']) ?></h4>
                        <p>Quantity: <?= $item['qty'] ?></p>
                    </div>
                    <div class="item-price">
                        <p>$<?= number_format($item['price'], 2) ?> × <?= $item['qty'] ?></p>
                        <p class="total">$<?= number_format($item['total_ht'], 2) ?></p>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
    
    <div class="success-actions">
        <a href="<?= BASE_URL ?>orders" class="btn">View All Orders</a>
        <a href="<?= BASE_URL ?>products" class="btn btn-primary">Continue Shopping</a>
    </div>
</div>

<?php require_once 'app/views/containers/footer.php'; ?>