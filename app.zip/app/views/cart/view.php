<div class="container mt-5">
    <div class="cart-container">
        <div class="cart-header">
            <h1>Shopping Cart</h1>
        </div>
        
        <?php if (isset($_SESSION['flash'])): ?>
            <div class="alert alert-<?php echo $_SESSION['flash']['type'] == 'error' ? 'danger' : $_SESSION['flash']['type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['flash']['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['flash']); ?>
        <?php endif; ?>
        
        <?php if (empty($cart)): ?>
            <div class="empty-cart-message">
                <h4>Your cart is empty</h4>
                <p>Looks like you haven't added any products to your cart yet.</p>
                <a href="index.php?page=products" class="btn btn-primary mt-3">Continue Shopping</a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart as $item): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="<?php echo $item['image_url']; ?>" alt="<?php echo $item['label']; ?>" class="cart-product-image me-3">
                                        <div class="cart-product-details">
                                            <h5 class="cart-product-title"><?php echo $item['label']; ?></h5>
                                            <small class="cart-product-code">Product Code: <?php echo $item['ref']; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>€<?php echo number_format($item['price'], 2); ?></td>
                                <td>
                                    <!-- Fix the form action to prevent infinite reloading -->
                                    <form action="index.php?page=cart&action=update" method="post" class="d-flex align-items-center">
                                        <input type="hidden" name="product_id" value="<?php echo $item['rowid']; ?>">
                                        <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" class="form-control cart-quantity-input">
                                        <button type="submit" class="btn btn-sm btn-outline-secondary ms-2 cart-update-btn">Update</button>
                                    </form>
                                </td>
                                <td>€<?php echo number_format($item['total_price'], 2); ?></td>
                                <td>
                                    <!-- Fix the remove link to prevent infinite reloading -->
                                    <a href="index.php?page=cart&action=remove&id=<?php echo $item['rowid']; ?>" class="btn btn-sm btn-remove">Remove</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr class="cart-total-row">
                            <td colspan="3" class="text-end"><strong>Total:</strong></td>
                            <td>€<?php echo number_format($totalPrice, 2); ?></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="cart-actions">
                <a href="index.php?page=products" class="btn btn-outline-primary">Continue Shopping</a>
                <div>
                    <a href="index.php?page=cart&action=clear" class="btn btn-outline-danger me-2">Clear Cart</a>
                    <a href="index.php?page=checkout" class="btn btn-success">Proceed to Checkout</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    /* Cart Container Styles */
    .cart-container {
        background-color: #ffffff;
        border-radius: 12px;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
        padding: 30px;
        margin-bottom: 40px;
        transition: all 0.3s ease;
    }
    
    .cart-header {
        border-bottom: 2px solid #f0f0f0;
        padding-bottom: 18px;
        margin-bottom: 25px;
        position: relative;
    }
    
    .cart-header h1 {
        color: #2c3e50;
        font-weight: 700;
        margin-bottom: 0;
        font-size: 2rem;
        letter-spacing: -0.5px;
    }
    
    .cart-header:after {
        content: '';
        position: absolute;
        bottom: -2px;
        left: 0;
        width: 80px;
        height: 4px;
        background: linear-gradient(90deg, #3498db, #2ecc71);
        border-radius: 2px;
    }
    
    /* Empty Cart Message */
    .empty-cart-message {
        text-align: center;
        padding: 60px 30px;
        background-color: #f8f9fa;
        border-radius: 10px;
        margin: 20px 0;
        border: 1px dashed #dee2e6;
    }
    
    .empty-cart-message h4 {
        color: #2c3e50;
        margin-bottom: 15px;
        font-weight: 600;
        font-size: 1.5rem;
    }
    
    .empty-cart-message p {
        color: #7f8c8d;
        margin-bottom: 25px;
        font-size: 1.1rem;
    }
    
    /* Table Styles */
    .table {
        margin-bottom: 0;
        border-collapse: separate;
        border-spacing: 0 8px;
    }
    
    .table thead th {
        border: none;
        font-weight: 600;
        color: #34495e;
        text-transform: uppercase;
        font-size: 0.85rem;
        letter-spacing: 1px;
        padding: 15px 10px;
        background-color: #f8f9fa;
        border-radius: 6px;
    }
    
    .table tbody tr {
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
        border-radius: 8px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .table-hover tbody tr:hover {
        background-color: #f8f9fa;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.07);
    }
    
    .table tbody td {
        padding: 15px 10px;
        vertical-align: middle;
        border-top: none;
    }
    
    .table tbody tr td:first-child {
        border-top-left-radius: 8px;
        border-bottom-left-radius: 8px;
    }
    
    .table tbody tr td:last-child {
        border-top-right-radius: 8px;
        border-bottom-right-radius: 8px;
    }
    
    /* Product Display */
    .cart-product-image {
        width: 90px;
        height: 90px;
        object-fit: contain;
        border: 1px solid #eee;
        border-radius: 8px;
        padding: 5px;
        background-color: #fff;
        transition: transform 0.3s ease;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
    }
    
    .cart-product-image:hover {
        transform: scale(1.05);
    }
    
    .cart-product-title {
        font-size: 1.1rem;
        font-weight: 600;
        margin-bottom: 6px;
        color: #2c3e50;
        transition: color 0.2s ease;
    }
    
    .cart-product-title:hover {
        color: #3498db;
    }
    
    .cart-product-code {
        font-size: 0.85rem;
        color: #95a5a6;
        background-color: #f8f9fa;
        padding: 3px 8px;
        border-radius: 4px;
        display: inline-block;
    }
    
    /* Quantity Controls */
    .cart-quantity-input {
        max-width: 70px;
        text-align: center;
        border-radius: 6px;
        border: 2px solid #e0e0e0;
        padding: 8px 5px;
        font-weight: 600;
        color: #2c3e50;
        transition: border-color 0.2s ease;
    }
    
    .cart-quantity-input:focus {
        border-color: #3498db;
        box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
    }
    
    .cart-update-btn {
        padding: 8px 12px;
        font-size: 0.85rem;
        font-weight: 600;
        border-radius: 6px;
        transition: all 0.3s ease;
        background-color: #f8f9fa;
        border-color: #e0e0e0;
        color: #7f8c8d;
    }
    
    .cart-update-btn:hover {
        background-color: #3498db;
        border-color: #3498db;
        color: white;
    }
    
    /* Total Row */
    .cart-total-row {
        font-weight: bold;
        font-size: 1.2rem;
        background-color: #f8f9fa;
        border-radius: 8px;
    }
    
    .cart-total-row td {
        padding: 20px 15px !important;
        color: #2c3e50;
    }
    
    /* Action Buttons */
    .cart-actions {
        margin-top: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .cart-actions .btn {
        padding: 12px 24px;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s ease;
        letter-spacing: 0.5px;
    }
    
    .btn-outline-primary {
        border-width: 2px;
    }
    
    .btn-outline-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
    }
    
    .btn-outline-danger {
        border-width: 2px;
    }
    
    .btn-outline-danger:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
    }
    
    .btn-success {
        background: linear-gradient(135deg, #2ecc71, #27ae60);
        border: none;
    }
    
    .btn-success:hover {
        background: linear-gradient(135deg, #27ae60, #2ecc71);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(46, 204, 113, 0.3);
    }
    
    .btn-remove {
        color: #e74c3c;
        border-color: #e74c3c;
        border-width: 2px;
        border-radius: 6px;
        padding: 6px 12px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .btn-remove:hover {
        background-color: #e74c3c;
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
    }
    
    /* Alert Messages */
    .alert {
        border-radius: 8px;
        margin-bottom: 25px;
        padding: 15px 20px;
        border-left: 5px solid;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }
    
    .alert-success {
        background-color: #d4edda;
        border-color: #2ecc71;
        color: #155724;
    }
    
    .alert-danger {
        background-color: #f8d7da;
        border-color: #e74c3c;
        color: #721c24;
    }
    
    /* Responsive Adjustments */
    @media (max-width: 992px) {
        .cart-container {
            padding: 25px 20px;
        }
    }
    
    @media (max-width: 768px) {
        .cart-actions {
            flex-direction: column;
            gap: 15px;
        }
        
        .cart-actions > a, 
        .cart-actions > div {
            width: 100%;
        }
        
        .cart-actions > div {
            display: flex;
            justify-content: space-between;
        }
        
        .cart-product-image {
            width: 70px;
            height: 70px;
        }
        
        .table thead th {
            font-size: 0.75rem;
        }
        
        .cart-header h1 {
            font-size: 1.75rem;
        }
    }
    
    @media (max-width: 576px) {
        .cart-container {
            padding: 20px 15px;
            border-radius: 8px;
        }
        
        .cart-product-image {
            width: 60px;
            height: 60px;
        }
        
        .cart-product-title {
            font-size: 0.95rem;
        }
        
        .cart-actions .btn {
            padding: 10px 16px;
            font-size: 0.9rem;
        }
    }
</style>