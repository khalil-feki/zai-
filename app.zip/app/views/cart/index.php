<?php require_once 'app/views/containers/header.php'; ?>

<div class="cart-container">
    <h1>Your Shopping Cart</h1>
    
    <?php if ($cartItems->rowCount() > 0): ?>
        <div class="cart-items">
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $cartItems->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td class="product-info">
                                <img src="<?= BASE_URL ?>public/images/products/<?= $item['product_id'] ?>.jpg" 
                                     alt="<?= htmlspecialchars($item['label']) ?>"
                                     onerror="this.src='<?= BASE_URL ?>public/images/no-image.jpg'">
                                <div>
                                    <h3><?= htmlspecialchars($item['label']) ?></h3>
                                    <a href="<?= BASE_URL ?>products/show/<?= $item['product_id'] ?>">View Product</a>
                                </div>
                            </td>
                            <td class="price">$<?= number_format($item['price'], 2) ?></td>
                            <td class="quantity">
                                <form action="<?= BASE_URL ?>cart/update" method="POST" class="quantity-form">
                                    <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                    <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" max="10">
                                    <button type="submit" class="btn btn-sm">Update</button>
                                </form>
                            </td>
                            <td class="total">$<?= number_format($item['total_price'], 2) ?></td>
                            <td class="actions">
                                <a href="<?= BASE_URL ?>cart/remove/<?= $item['product_id'] ?>" class="btn btn-danger btn-sm">Remove</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-right"><strong>Subtotal:</strong></td>
                        <td class="total"><strong>$<?= number_format($cartTotal, 2) ?></strong></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
            
            <div class="cart-actions">
                <a href="<?= BASE_URL ?>products" class="btn">Continue Shopping</a>
                <a href="<?= BASE_URL ?>cart/clear" class="btn btn-danger">Clear Cart</a>
                <a href="<?= BASE_URL ?>checkout" class="btn btn-primary">Proceed to Checkout</a>
            </div>
        </div>
    <?php else: ?>
        <div class="empty-cart">
            <p>Your cart is empty.</p>
            <a href="<?= BASE_URL ?>products" class="btn btn-primary">Start Shopping</a>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'app/views/containers/footer.php'; ?>