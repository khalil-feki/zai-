<div class="container mt-5">
    <div class="row">
        <!-- Product image column -->
        <div class="col-md-6">
            <img src="<?php echo htmlspecialchars($product['image_url'] ?? 'public/img/placeholder.jpg'); ?>" alt="<?php echo htmlspecialchars($product['label'] ?? 'Product Image'); ?>" class="img-fluid product-detail-image">
        </div>
        
        <!-- Product info column -->
        <div class="col-md-6">
            <h1><?php echo htmlspecialchars($product['label'] ?? 'Product Name'); ?></h1>
            <p class="text-muted">Product Code: <?php echo htmlspecialchars($product['ref'] ?? 'N/A'); ?></p>
            
            <div class="price-container my-3">
                <h3 class="text-primary">$<?php echo number_format($product['price'] ?? 0, 2); ?></h3>
            </div>
            
            <div class="description my-4">
                <h4>Description</h4>
                <p><?php echo nl2br(htmlspecialchars($product['description'] ?? 'No description available')); ?></p>
            </div>
            
            <!-- Fixed cart form action -->
            <form action="index.php?page=cart&action=add" method="post" id="addToCartForm">
                <input type="hidden" name="product_id" value="<?php echo $product['rowid'] ?? 0; ?>">
                <div class="quantity mb-3">
                    <label for="quantity">Quantity:</label>
                    <input type="number" name="quantity" id="quantity" value="1" min="1" class="form-control" style="width: 100px;">
                </div>
                <button type="submit" class="btn btn-primary btn-lg">Add to Cart</button>
            </form>
            
            <!-- Additional product details -->
            <div class="additional-info mt-4">
                <p><strong>Category:</strong> <?php echo isset($product['category_name']) ? htmlspecialchars($product['category_name']) : 'Uncategorized'; ?></p>
                <p><strong>Availability:</strong> <?php echo (isset($product['tosell']) && $product['tosell'] == 1) ? 'In Stock' : 'Out of Stock'; ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Similar products section -->
<?php if (!empty($similarProducts)): ?>
<div class="container mt-5">
    <h2>You may also like</h2>
    <div class="row">
        <?php foreach ($similarProducts as $similarProduct): ?>
            <div class="col-md-3 mb-4">
                <div class="card h-100">
                    <img src="<?php echo htmlspecialchars($similarProduct['image_url'] ?? 'public/img/placeholder.jpg'); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($similarProduct['label'] ?? 'Product Image'); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($similarProduct['label'] ?? 'Product Name'); ?></h5>
                        <p class="card-text">$<?php echo number_format($similarProduct['price'] ?? 0, 2); ?></p>
                        <a href="index.php?page=products&action=show&id=<?php echo $similarProduct['rowid'] ?? 0; ?>" class="btn btn-outline-primary">View Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Add CSS for product detail page -->
<style>
    .product-detail-image {
        max-height: 400px;
        object-fit: contain;
        border: 1px solid #eee;
        border-radius: 5px;
        padding: 10px;
        background-color: #fff;
    }
    
    .price-container {
        border-top: 1px solid #eee;
        border-bottom: 1px solid #eee;
        padding: 15px 0;
    }
    
    .description {
        line-height: 1.6;
    }
    
    .quantity label {
        margin-right: 10px;
        font-weight: 500;
    }
    
    .additional-info {
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
    }
    
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    
    .card-img-top {
        height: 200px;
        object-fit: contain;
        padding: 15px;
    }
    
    /* Shopping Cart Styles */
    .cart-container {
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 20px rgba(0,0,0,0.05);
        padding: 25px;
        margin-bottom: 30px;
    }
    
    .cart-header {
        border-bottom: 2px solid #f0f0f0;
        padding-bottom: 15px;
        margin-bottom: 20px;
    }
    
    .cart-product-image {
        max-width: 80px;
        max-height: 80px;
        object-fit: contain;
        border: 1px solid #eee;
        border-radius: 4px;
    }
    
    .cart-product-details {
        margin-left: 15px;
    }
    
    .cart-product-title {
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .cart-product-code {
        font-size: 0.85rem;
        color: #6c757d;
    }
    
    .cart-quantity-input {
        max-width: 70px;
        text-align: center;
    }
    
    .cart-update-btn {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
    }
    
    .cart-total-row {
        font-weight: bold;
        font-size: 1.1rem;
        background-color: #f8f9fa;
    }
    
    .cart-actions {
        margin-top: 20px;
        display: flex;
        justify-content: space-between;
    }
    
    .cart-actions .btn {
        padding: 10px 20px;
    }
    
    .alert-success {
        background-color: #d4edda;
        border-color: #c3e6cb;
        color: #155724;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
    }
    
    .table-hover tbody tr:hover {
        background-color: rgba(0,123,255,0.05);
    }
    
    .btn-remove {
        color: #dc3545;
        border-color: #dc3545;
    }
    
    .btn-remove:hover {
        background-color: #dc3545;
        color: white;
    }
    
    .empty-cart-message {
        text-align: center;
        padding: 30px;
        background-color: #f8f9fa;
        border-radius: 8px;
        margin: 20px 0;
    }
</style>