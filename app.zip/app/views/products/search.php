<?php require_once 'app/views/containers/header.php'; ?>

<div class="container mt-4">
    <h1>Search Results</h1>
    
    <!-- Debug information removed -->
    
    <div class="row mb-4">
        <div class="col-md-12">
            <!-- Replace the part that's using $categories with this code -->
            <!-- Remove category dropdown from search form -->
            <form action="<?= BASE_URL ?>products/search" method="GET" class="search-form">
                <div class="form-group">
                    <input type="text" name="keyword" class="form-control" placeholder="Search products..." 
                           value="<?= htmlspecialchars($keyword ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label for="min_price">Min Price</label>
                    <input type="number" id="min_price" name="min_price" class="form-control" 
                           min="0" step="0.01" value="<?= htmlspecialchars($minPrice ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label for="max_price">Max Price</label>
                    <input type="number" id="max_price" name="max_price" class="form-control" 
                           min="0" step="0.01" value="<?= htmlspecialchars($maxPrice ?? '') ?>">
                </div>
                
                <button type="submit" class="btn btn-primary">Search</button>
            </form>
        </div>
    </div>
    
    <div class="row">
        <?php if (empty($products)): ?>
            <div class="col-12">
                <div class="alert alert-info">No products found matching your criteria.</div>
            </div>
        <?php else: ?>
            <!-- Replace the existing product card HTML with this enhanced version -->
            <?php foreach ($products as $product): ?>
                <div class="col-md-6 mb-5">
                    <div class="card h-100">
                        <div class="card-body p-4">
                            <h4 class="card-title"><?= $product['label'] ?></h4>
                            
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <?php 
                                    $imagePath = 'public/img/products/h8pd_product_' . $product['rowid'] . '.jpg';
                                    $imageUrl = file_exists($imagePath) ? BASE_URL . $imagePath : BASE_URL . 'public/img/products/placeholder.jpg';
                                    ?>
                                    <div class="product-image-container">
                                        <img src="<?= $imageUrl ?>" alt="<?= $product['label'] ?>" class="img-fluid">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <span class="category-badge"><?= $product['category_name'] ?? 'Uncategorized' ?></span>
                                    <p class="card-text"><?= truncateText($product['description'], 200) ?></p>
                                    <p class="card-text"><strong>Price: </strong><span class="text-primary h5"><?= formatCurrency($product['price']) ?></span></p>
                                    
                                    <div class="cart-actions">
                                        <a href="<?= BASE_URL ?>products/view/<?= $product['rowid'] ?>" class="btn btn-primary">View Details</a>
                                        <!-- Update the add to cart form -->
                                        <form action="<?= BASE_URL ?>cart/add" method="POST" class="add-to-cart-form">
                                            <input type="hidden" name="product_id" value="<?= $product['rowid'] ?>">
                                            <input type="number" name="quantity" value="1" min="1" max="10" class="form-control quantity-input">
                                            <button type="submit" class="btn btn-primary">Add to Cart</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <?php if (isset($totalPages) && $totalPages > 1): ?>
        <div class="mt-4">
            <?= generatePagination($page, $totalPages, BASE_URL . 'products/search?' . http_build_query(array_filter([
                'keyword' => $keyword,
                'category' => $category,
                'min_price' => $minPrice,
                'max_price' => $maxPrice,
                'page' => '%d'
            ]))) ?>
        </div>
    <?php endif; ?>
</div>

<!-- Add custom styles for product cards -->
<!-- Update the CSS for bigger cards -->
<!-- Update the CSS for much bigger cards -->
<style>
    /* Enhanced product card styling with MUCH bigger dimensions */
    .card {
        transition: all 0.3s ease;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        min-height: 500px; /* Significantly increased height */
        margin-bottom: 30px;
    }
    .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 16px 32px rgba(0,0,0,0.15);
    }
    .product-image-container {
        height: 350px; /* Much taller image container */
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        background-color: #f8f9fa;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    .product-image-container img {
        max-height: 100%;
        max-width: 100%;
        object-fit: contain;
        transition: transform 0.3s ease;
    }
    .product-image-container:hover img {
        transform: scale(1.05);
    }
    .card-title {
        font-weight: 700;
        color: #343a40;
        margin-bottom: 20px;
        border-bottom: 2px solid #eee;
        padding-bottom: 15px;
        font-size: 1.8rem; /* Larger title */
    }
    .card-text {
        color: #495057;
        margin-bottom: 15px;
        line-height: 1.6;
        font-size: 1.2rem; /* Larger text */
    }
    .text-primary.h5 {
        font-weight: 700;
        color: #007bff !important;
        font-size: 1.6rem; /* Larger price */
    }
    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        padding: 12px 24px; /* Larger buttons */
        font-weight: 600;
        transition: all 0.2s;
        font-size: 1.2rem;
        border-radius: 6px;
    }
    .btn-primary:hover {
        background-color: #0069d9;
        border-color: #0062cc;
        transform: translateY(-3px);
    }
    .btn-success {
        background-color: #28a745;
        border-color: #28a745;
        padding: 12px 24px; /* Larger buttons */
        font-weight: 600;
        transition: all 0.2s;
        font-size: 1.2rem;
        border-radius: 6px;
    }
    .btn-success:hover {
        background-color: #218838;
        border-color: #1e7e34;
        transform: translateY(-3px);
    }
    /* Improved layout for product cards */
    .card-body {
        padding: 2.5rem; /* More padding */
    }
    .cart-form {
        margin-top: 15px;
        width: 100%;
    }
    .input-group {
        width: 100%;
        display: flex;
    }
    /* Make quantity input bigger */
    input[type="number"] {
        width: 100px; /* Wider input */
        text-align: center;
        border-radius: 6px 0 0 6px;
        border: 2px solid #ced4da;
        height: 55px; /* Taller input */
        font-size: 1.2rem;
    }
    /* Category badge styling */
    .category-badge {
        display: inline-block;
        background-color: #e9ecef;
        color: #495057;
        padding: 8px 16px;
        border-radius: 6px;
        font-size: 1.1rem;
        margin-bottom: 20px;
    }
    .cart-actions {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        margin-top: 25px; /* More space above actions */
    }
    /* Make buttons full width for better visibility */
    .cart-actions .btn {
        width: 100%;
        margin-bottom: 15px;
        text-align: center;
    }
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .card-body {
            padding: 1.8rem;
        }
        .product-image-container {
            height: 250px;
        }
    }
    /* Fix for filter button */
    .btn-block {
        display: block;
        width: 100%;
    }
    /* Make the filter form more responsive */
    @media (max-width: 768px) {
        .form-group {
            margin-bottom: 15px;
        }
        .col-md-1 .btn {
            width: 100%;
            padding: 10px;
        }
    }
</style>

<?php require_once 'app/views/containers/footer.php'; ?>