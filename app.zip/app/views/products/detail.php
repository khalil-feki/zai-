<!-- Product details section -->
<div class="container mt-5">
    <div class="row">
        <!-- Product image column -->
        <div class="col-md-6">
            <img src="<?php echo $product['image_url']; ?>" alt="<?php echo $product['label']; ?>" class="img-fluid product-detail-image">
        </div>
        
        <!-- Product info column -->
        <div class="col-md-6">
            <h1><?php echo $product['label']; ?></h1>
            <p class="text-muted">Product Code: <?php echo $product['ref']; ?></p>
            
            <div class="price-container my-3">
                <h3 class="text-primary">€<?php echo number_format($product['price'], 2); ?></h3>
            </div>
            
            <div class="description my-4">
                <h4>Description</h4>
                <p><?php echo nl2br($product['description']); ?></p>
            </div>
            
            <!-- Add to cart form -->
            <form action="index.php?page=cart&action=add" method="post">
                <input type="hidden" name="product_id" value="<?php echo $product['rowid']; ?>">
                <div class="quantity mb-3">
                    <label for="quantity">Quantity:</label>
                    <input type="number" name="quantity" id="quantity" value="1" min="1" class="form-control" style="width: 100px;">
                </div>
                <button type="submit" class="btn btn-primary btn-lg">Add to Cart</button>
            </form>
            
            <!-- Additional product details -->
            <div class="additional-info mt-4">
                <p><strong>Category:</strong> <?php echo isset($product['category_name']) ? $product['category_name'] : 'Uncategorized'; ?></p>
                <p><strong>Availability:</strong> <?php echo ($product['tosell'] == 1) ? 'In Stock' : 'Out of Stock'; ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Related products section -->
<div class="container mt-5">
    <h2>You may also like</h2>
    <div class="row">
        <?php foreach ($relatedProducts as $relatedProduct): ?>
            <div class="col-md-3 mb-4">
                <div class="card h-100">
                    <img src="<?php echo $relatedProduct['image_url']; ?>" class="card-img-top" alt="<?php echo $relatedProduct['label']; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $relatedProduct['label']; ?></h5>
                        <p class="card-text">€<?php echo number_format($relatedProduct['price'], 2); ?></p>
                        <a href="index.php?page=products&action=detail&id=<?php echo $relatedProduct['rowid']; ?>" class="btn btn-outline-primary">View Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>