<?php require_once 'app/views/containers/header.php'; ?>

<div class="products-container">
     <div class="sidebar">
        <h3>Filter Products</h3>
        <div class="filter-section">
            <form action="<?= BASE_URL ?>products/search" method="GET" class="filter-form">
                <div class="form-group">
                    <label for="keyword">Search</label>
                    <input type="text" id="keyword" name="keyword" placeholder="Search products..." 
                           value="<?= isset($_GET['keyword']) ? htmlspecialchars($_GET['keyword']) : '' ?>">
                </div>
                
                <div class="form-group">
                    <label for="price-range">Price Range</label>
                    <div class="price-inputs">
                        <input type="number" id="min_price" name="min_price" placeholder="Min" min="0" step="0.01"
                               value="<?= isset($_GET['min_price']) ? htmlspecialchars($_GET['min_price']) : '' ?>">
                        <span>to</span>
                        <input type="number" id="max_price" name="max_price" placeholder="Max" min="0" step="0.01"
                               value="<?= isset($_GET['max_price']) ? htmlspecialchars($_GET['max_price']) : '' ?>">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Apply Filters</button>
                <a href="<?= BASE_URL ?>products" class="btn btn-secondary">Reset</a>
            </form>
        </div>
    </div>
    
    <div class="products-grid">
        <div class="products-header">
            <h1>All Products</h1>
            <div class="sort-options">
                <!-- Sort options if needed -->
            </div>
        </div>
        
        <?php if (!empty($products)): ?>
            <div class="products-list">
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php 
                            $imagePath = 'public/img/products/h8pd_product_' . $product['rowid'] . '.jpg';
                            $imageUrl = file_exists($imagePath) ? BASE_URL . $imagePath : BASE_URL . 'public/img/products/placeholder.jpg';
                            ?>
                            <img src="<?= $imageUrl ?>" alt="<?= htmlspecialchars($product['label']) ?>">
                        </div>
                        <div class="product-details">
                            <h3><?= htmlspecialchars($product['label']) ?></h3>
                            <p class="price"><?= formatCurrency($product['price']) ?></p>
                            <div class="product-actions">
                                <a href="<?= BASE_URL ?>products/show/<?= $product['rowid'] ?>" class="btn btn-primary">View Details</a>
                                <form action="<?= BASE_URL ?>cart/add" method="POST" class="add-to-cart-form">
                                    <input type="hidden" name="product_id" value="<?= $product['rowid'] ?>">
                                    <input type="number" name="quantity" value="1" min="1" max="10" class="quantity-input">
                                    <button type="submit" class="btn btn-primary">Add to Cart</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="no-products">
                <p>No products found. Please try a different search.</p>
            </div>
        <?php endif; ?>
        
        <?php if (isset($totalPages) && $totalPages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="<?= BASE_URL ?>products?page=<?= $i ?>" class="<?= $page == $i ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'app/views/containers/footer.php'; ?>