<?php require_once 'app/views/containers/header.php'; ?>

<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>products">Products</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= $product['label'] ?></li>
        </ol>
    </nav>
    
    <div class="row">
        <div class="col-md-6">
            <img src="<?= BASE_URL ?>public/img/products/placeholder.jpg" alt="<?= $product['label'] ?>" class="img-fluid">
        </div>
        <div class="col-md-6">
            <h1><?= $product['label'] ?></h1>
            <p class="lead"><?= formatCurrency($product['price']) ?></p>
            
            <?php if ($product['stock'] > 0): ?>
                <p class="text-success">In Stock (<?= $product['stock'] ?> available)</p>
            <?php else: ?>
                <p class="text-danger">Out of Stock</p>
            <?php endif; ?>
            
            <p><?= $product['description'] ?></p>
            
            <form action="<?= BASE_URL ?>cart/add" method="POST" class="mb-3">
                <input type="hidden" name="product_id" value="<?= $product['rowid'] ?>">
                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                
                <div class="form-group">
                    <label for="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" class="form-control" value="1" min="1" max="<?= $product['stock'] ?>" style="width: 100px;">
                </div>
                
                <button type="submit" class="btn btn-lg btn-success" <?= $product['stock'] <= 0 ? 'disabled' : '' ?>>
                    <i class="fas fa-shopping-cart"></i> Add to Cart
                </button>
            </form>
            
            <div class="card mt-4">
                <div class="card-header">
                    Product Details
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>SKU:</strong> <?= $product['ref'] ?></li>
                    <li class="list-group-item"><strong>Category:</strong> <?= $product['category_name'] ?? 'Uncategorized' ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php require_once 'app/views/containers/footer.php'; ?>