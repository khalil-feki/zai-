<?php require_once 'app/views/containers/header.php'; ?>

<section class="categories-hero">
    <div class="container">
        <div class="hero-content fade-in-up">
            <h1>Explore Our <span>Categories</span></h1>
            <p>Discover amazing products organized by categories</p>
        </div>
    </div>
</section>

<section class="main-content">
    <div class="container">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error fade-in-up">
                <?= $_SESSION['error']; ?>
                <?php unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
        
        <div class="content-layout">
            <!-- Left sidebar with categories -->
            <div class="category-sidebar">
                <h2>Browse Categories</h2>
                <div class="category-menu">
                    <?php if (!empty($categories)): ?>
                        <?php foreach ($categories as $category): ?>
                            <div class="sidebar-category-item fade-in-up stagger-item" data-category-id="<?= $category['rowid']; ?>">
                                <div class="sidebar-category-image">
                                    <img src="<?= BASE_URL . 'public/images/categories/' . (isset($category['image']) ? $category['image'] : 'default-category.jpg'); ?>" alt="<?= htmlspecialchars($category['label']); ?>">
                                </div>
                                <div class="sidebar-category-content">
                                    <h3><?= htmlspecialchars($category['label']); ?></h3>
                                    <a href="<?= BASE_URL; ?>category/view/<?= $category['rowid']; ?>" class="btn-text">Explore <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-results">
                            <i class="fas fa-search"></i>
                            <h3>No categories found</h3>
                            <p>Please check back later for new categories.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right content with featured and trending products -->
            <div class="products-content">
                <!-- Featured Products Section -->
                <section class="featured-products">
                    <div class="section-title">
                        <h2>Featured <span>Products</span></h2>
                        <p>Discover our most popular items across all categories</p>
                    </div>
                    
                    <div class="products-slider">
                        <?php if (!empty($featuredProducts)): ?>
                            <?php foreach ($featuredProducts as $product): ?>
                                <div class="product-card fade-in-up stagger-item">
                                    <div class="product-badge">Featured</div>
                                    <div class="product-image-container">
                                        <img src="<?= BASE_URL . ($product['image_url'] ?? 'public/images/products/default.jpg'); ?>" alt="<?= htmlspecialchars($product['label']); ?>">
                                        <div class="product-actions">
                                            <a href="<?= BASE_URL; ?>product/view/<?= $product['rowid']; ?>" class="action-btn"><i class="fas fa-eye"></i></a>
                                            <button class="action-btn add-to-cart" data-product-id="<?= $product['rowid']; ?>"><i class="fas fa-shopping-cart"></i></button>
                                            <button class="action-btn add-to-wishlist" data-product-id="<?= $product['rowid']; ?>"><i class="fas fa-heart"></i></button>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <h3 class="product-title"><?= htmlspecialchars($product['label']); ?></h3>
                                        <div class="product-price">€<?= number_format($product['price'], 2); ?></div>
                                        <div class="product-rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star-half-alt"></i>
                                            <span>(4.5)</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-results">
                                <i class="fas fa-box-open"></i>
                                <h3>No featured products available</h3>
                                <p>Please check back later for new products.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

                <!-- Trending Products Section -->
                <section class="trending-products">
                    <div class="section-title">
                        <h2>Trending <span>Now</span></h2>
                        <p>Hot items that customers are loving right now</p>
                    </div>
                    
                    <div class="trending-grid">
                        <?php if (!empty($trendingProducts)): ?>
                            <?php foreach ($trendingProducts as $product): ?>
                                <div class="trending-card fade-in-up stagger-item">
                                    <div class="trending-image">
                                        <img src="<?= BASE_URL . ($product['image_url'] ?? 'public/images/products/default.jpg'); ?>" alt="<?= htmlspecialchars($product['label']); ?>">
                                    </div>
                                    <div class="trending-content">
                                        <h3><?= htmlspecialchars($product['label']); ?></h3>
                                        <div class="trending-price">€<?= number_format($product['price'], 2); ?></div>
                                        <a href="<?= BASE_URL; ?>product/view/<?= $product['rowid']; ?>" class="btn-primary">View Details</a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>
            </div>
        </div>
    </div>
</section>

<style>
/* Main content layout styling */
.main-content {
    padding: 40px 0;
}

.content-layout {
    display: flex;
    gap: 30px;
}

/* Category sidebar styling */
.category-sidebar {
    flex: 0 0 300px;
    background: white;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    padding: 20px;
    height: fit-content;
}

.category-sidebar h2 {
    font-size: 1.8rem;
    margin-bottom: 20px;
    color: var(--text-color);
    border-bottom: 2px solid var(--primary-color);
    padding-bottom: 10px;
}

.category-menu {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.sidebar-category-item {
    display: flex;
    align-items: center;
    padding: 10px;
    border-radius: 10px;
    transition: all 0.3s ease;
    cursor: pointer;
    background: #f9f9f9;
}

.sidebar-category-item:hover {
    transform: translateX(5px);
    background: #f0f0f0;
}

.sidebar-category-image {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    overflow: hidden;
    margin-right: 15px;
}

.sidebar-category-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.sidebar-category-content {
    flex: 1;
}

.sidebar-category-content h3 {
    margin: 0 0 5px;
    font-size: 1.1rem;
    font-weight: 600;
}

/* Products content styling */
.products-content {
    flex: 1;
}

.featured-products, .trending-products {
    background: white;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    padding: 25px;
    margin-bottom: 30px;
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .content-layout {
        flex-direction: column;
    }
    
    .category-sidebar {
        flex: 0 0 100%;
        margin-bottom: 30px;
    }
}

/* Keep existing styles for products */
.products-slider {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.trending-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 20px;
}

/* Remove the categories-showcase section styles as we've replaced it */
.categories-showcase {
    display: none;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add to cart functionality
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.getAttribute('data-product-id');
            
            // Add animation effect
            this.classList.add('adding');
            
            // AJAX request to add product to cart
            fetch(BASE_URL + 'cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'product_id=' + productId + '&quantity=1'
            })
            .then(response => response.json())
            .then(data => {
                setTimeout(() => {
                    this.classList.remove('adding');
                    if (data.success) {
                        this.classList.add('added');
                        setTimeout(() => {
                            this.classList.remove('added');
                        }, 1500);
                        
                        // Update cart count if needed
                        updateCartCount(data.cartCount || 1);
                    } else {
                        alert(data.message || 'Failed to add product to cart');
                    }
                }, 800);
            })
            .catch(error => {
                console.error('Error:', error);
                this.classList.remove('adding');
                alert('An error occurred. Please try again.');
            });
        });
    });
    
    // Category item hover effects
    const categoryItems = document.querySelectorAll('.sidebar-category-item');
    categoryItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.classList.add('hover');
        });
        
        item.addEventListener('mouseleave', function() {
            this.classList.remove('hover');
        });
    });
    
    function updateCartCount(count) {
        const cartBadge = document.querySelector('.cart-badge');
        if (cartBadge) {
            cartBadge.textContent = count;
            cartBadge.style.display = count > 0 ? 'inline-block' : 'none';
        }
    }
});
</script>

<style>
/* Modern Categories Page Styling */
.categories-hero {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    padding: 80px 0;
    text-align: center;
    margin-bottom: 60px;
    border-radius: 0 0 50% 50% / 20px;
    position: relative;
    overflow: hidden;
}

.categories-hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url('<?= BASE_URL ?>public/images/pattern.svg');
    opacity: 0.1;
}

.hero-content {
    position: relative;
    z-index: 1;
}

.categories-hero h1 {
    color: white;
    font-size: 3rem;
    margin-bottom: 15px;
    font-weight: 700;
}

.categories-hero h1 span {
    color: #ffeb3b;
}

.categories-hero p {
    color: rgba(255, 255, 255, 0.9);
    font-size: 1.2rem;
    max-width: 600px;
    margin: 0 auto;
}

.categories-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 30px;
    margin-bottom: 60px;
}

.category-card {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    position: relative;
    cursor: pointer;
}

.category-card:hover, .category-card.hover {
    transform: translateY(-15px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}

.category-image {
    height: 200px;
    overflow: hidden;
}

.category-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.8s ease;
}

.category-card:hover .category-image img, .category-card.hover .category-image img {
    transform: scale(1.1);
}

.category-content {
    padding: 25px;
    position: relative;
}

.category-content h3 {
    margin: 0 0 10px;
    font-size: 1.5rem;
    font-weight: 600;
    color: var(--text-color);
}

.category-content p {
    color: var(--secondary-color);
    margin-bottom: 20px;
    font-size: 0.95rem;
    line-height: 1.5;
}

.btn-text {
    color: var(--primary-color);
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    transition: all 0.3s ease;
}

.btn-text i {
    margin-left: 8px;
    transition: transform 0.3s ease;
}

.btn-text:hover {
    color: var(--primary-dark);
}

.btn-text:hover i {
    transform: translateX(5px);
}

.section-title {
    text-align: center;
    margin-bottom: 40px;
}

.section-title h2 {
    font-size: 2.5rem;
    color: var(--text-color);
    margin-bottom: 15px;
    font-weight: 700;
}

.section-title h2 span {
    color: var(--primary-color);
}

.section-title p {
    color: var(--secondary-color);
    font-size: 1.1rem;
    max-width: 700px;
    margin: 0 auto;
}

.products-slider {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 25px;
    margin-bottom: 60px;
}

.product-card {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    position: relative;
}

.product-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}

.product-badge {
    position: absolute;
    top: 15px;
    left: 15px;
    background: var(--primary-color);
    color: white;
    padding: 5px 12px;
    border-radius: 30px;
    font-size: 0.8rem;
    font-weight: 600;
    z-index: 2;
}

.product-image-container {
    height: 220px;
    position: relative;
    overflow: hidden;
    background: #f9f9f9;
}

.product-image-container img {
    width: 100%;
    height: 100%;
    object-fit: contain;
    transition: transform 0.5s ease;
}

.product-card:hover .product-image-container img {
    transform: scale(1.08);
}

.product-actions {
    position: absolute;
    bottom: -50px;
    left: 0;
    width: 100%;
    display: flex;
    justify-content: center;
    gap: 10px;
    padding: 10px;
    background: rgba(255, 255, 255, 0.9);
    transition: bottom 0.3s ease;
}

.product-card:hover .product-actions {
    bottom: 0;
}

.action-btn {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: white;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-color);
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
    text-decoration: none;
}

.action-btn:hover {
    background: var(--primary-color);
    color: white;
    transform: translateY(-3px);
}

.action-btn.adding {
    animation: adding 0.8s ease;
}

.action-btn.added {
    background: var(--success-color);
    color: white;
}

@keyframes adding {
    0% { transform: scale(1); }
    50% { transform: scale(0.8); }
    100% { transform: scale(1); }
}

.product-info {
    padding: 20px;
}

.product-title {
    font-size: 1.1rem;
    font-weight: 600;
    margin: 0 0 10px;
    color: var(--text-color);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.product-price {
    font-size: 1.2rem;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 10px;
}

.product-rating {
    display: flex;
    align-items: center;
    color: #ffc107;
    font-size: 0.9rem;
}

.product-rating span {
    color: var(--secondary-color);
    margin-left: 5px;
}

.trending-products {
    background: #f8f9fa;
    padding: 80px 0;
    margin-top: 40px;
}

.trending-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 30px;
}

.trending-card {
    display: flex;
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.trending-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}

.trending-image {
    width: 40%;
    overflow: hidden;
}

.trending-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.trending-card:hover .trending-image img {
    transform: scale(1.08);
}

.trending-content {
    width: 60%;
    padding: 20px;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.trending-content h3 {
    margin: 0 0 10px;
    font-size: 1.2rem;
    font-weight: 600;
    color: var(--text-color);
}

.trending-price {
    font-size: 1.3rem;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 15px;
}

.btn-primary {
    background: linear-gradient(45deg, var(--primary-color), var(--primary-dark));
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 30px;
    font-weight: 600;
    text-decoration: none;
    display: inline-block;
    text-align: center;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(74, 108, 247, 0.3);
}

.btn-primary:hover {
    background: linear-gradient(45deg, var(--primary-dark), var(--primary-color));
    box-shadow: 0 6px 20px rgba(74, 108, 247, 0.4);
    transform: translateY(-2px);
}

.no-results {
    text-align: center;
    padding: 50px 0;
    color: var(--secondary-color);
}

.no-results i {
    font-size: 3rem;
    margin-bottom: 20px;
    color: var(--primary-color);
    opacity: 0.5;
}

.no-results h3 {
    font-size: 1.5rem;
    margin-bottom: 10px;
    color: var(--text-color);
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .categories-hero h1 {
        font-size: 2.5rem;
    }
    
    .section-title h2 {
        font-size: 2rem;
    }
    
    .trending-card {
        flex-direction: column;
    }
    
    .trending-image, .trending-content {
        width: 100%;
    }
    
    .trending-image {
        height: 200px;
    }
}

@media (max-width: 768px) {
    .categories-hero {
        padding: 60px 0;
    }
    
    .categories-hero h1 {
        font-size: 2rem;
    }
    
    .categories-grid, .products-slider, .trending-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    }
}

@media (max-width: 576px) {
    .categories-grid, .products-slider, .trending-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<?php require_once 'app/views/containers/footer.php'; ?>