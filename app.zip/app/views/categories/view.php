<?php require_once 'app/views/containers/header.php'; ?>

<div class="container mt-4">
    <div class="row">
        <!-- Categories Sidebar -->
            <!-- Filters -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Filter Products</h5>
                </div>
                <div class="card-body">
                    <form action="<?= BASE_URL; ?>category/view/<?= $currentCategory['rowid']; ?>" method="GET" id="filter-form">
                        <div class="mb-3">
                            <label for="search" class="form-label">Search</label>
                            <input type="text" class="form-control" id="search" name="search" 
                                   value="<?= htmlspecialchars($search ?? ''); ?>" placeholder="Search in this category">
                        </div>
                        
                        <div class="mb-3">
                            <label for="price-range" class="form-label">Price Range</label>
                            <div class="d-flex">
                                <input type="number" class="form-control me-2" id="min_price" name="min_price" 
                                       value="<?= $minPrice ?? ''; ?>" placeholder="Min" min="0" step="0.01">
                                <input type="number" class="form-control" id="max_price" name="max_price" 
                                       value="<?= $maxPrice ?? ''; ?>" placeholder="Max" min="0" step="0.01">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="sort" class="form-label">Sort By</label>
                            <select class="form-select" id="sort" name="sort">
                                <option value="newest" <?= ($sort === 'newest') ? 'selected' : ''; ?>>Newest</option>
                                <option value="price_asc" <?= ($sort === 'price_asc') ? 'selected' : ''; ?>>Price: Low to High</option>
                                <option value="price_desc" <?= ($sort === 'price_desc') ? 'selected' : ''; ?>>Price: High to Low</option>
                                <option value="name_asc" <?= ($sort === 'name_asc') ? 'selected' : ''; ?>>Name: A to Z</option>
                                <option value="name_desc" <?= ($sort === 'name_desc') ? 'selected' : ''; ?>>Name: Z to A</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                        <a href="<?= BASE_URL; ?>category/view/<?= $currentCategory['rowid']; ?>" class="btn btn-outline-secondary w-100 mt-2">Reset Filters</a>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Products Content -->
        <div class="col-md-9">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL; ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?= BASE_URL; ?>category">Categories</a></li>
                    <li class="breadcrumb-item active"><?= htmlspecialchars($currentCategory['label']); ?></li>
                </ol>
            </nav>
            
            <h1><?= htmlspecialchars($currentCategory['label']); ?></h1>
            
            <?php if (!empty($currentCategory['description'])): ?>
                <p class="lead"><?= htmlspecialchars($currentCategory['description']); ?></p>
            <?php endif; ?>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <p class="mb-0"><?= count($products); ?> products found</p>
                <div class="btn-group">
                    <button type="button" class="btn btn-outline-secondary view-grid active">
                        <i class="fas fa-th"></i>
                    </button>
                    <button type="button" class="btn btn-outline-secondary view-list">
                        <i class="fas fa-list"></i>
                    </button>
                </div>
            </div>
            
            <?php if (!empty($products)): ?>
                <div class="row products-grid">
                    <?php foreach ($products as $product): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 product-card">
                                <img src="<?= BASE_URL . ($product['image_url'] ?? 'public/uploads/products/default.jpg'); ?>" 
                                     class="card-img-top" alt="<?= htmlspecialchars($product['label']); ?>">
                                <div class="card-body">
                                    <h5 class="card-title"><?= htmlspecialchars($product['label']); ?></h5>
                                    <p class="card-text">
                                        <?= !empty($product['description']) ? htmlspecialchars(substr($product['description'], 0, 80)) . '...' : ''; ?>
                                    </p>
                                    <p class="card-text text-primary font-weight-bold">
                                        €<?= number_format($product['price'], 2); ?>
                                    </p>
                                </div>
                                <div class="card-footer bg-white border-top-0">
                                    <a href="<?= BASE_URL; ?>product/view/<?= $product['rowid']; ?>" class="btn btn-sm btn-outline-primary">View Details</a>
                                    <button class="btn btn-sm btn-success add-to-cart" data-product-id="<?= $product['rowid']; ?>">
                                        <i class="fas fa-cart-plus"></i> Add to Cart
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="products-list d-none">
                    <?php foreach ($products as $product): ?>
                        <div class="card mb-3 product-list-item">
                            <div class="row g-0">
                                <div class="col-md-3">
                                    <img src="<?= BASE_URL . ($product['image_url'] ?? 'public/uploads/products/default.jpg'); ?>" 
                                         class="img-fluid rounded-start" alt="<?= htmlspecialchars($product['label']); ?>">
                                </div>
                                <div class="col-md-9">
                                    <div class="card-body">
                                        <h5 class="card-title"><?= htmlspecialchars($product['label']); ?></h5>
                                        <p class="card-text">
                                            <?= !empty($product['description']) ? htmlspecialchars(substr($product['description'], 0, 150)) . '...' : ''; ?>
                                        </p>
                                        <p class="card-text text-primary font-weight-bold">
                                            €<?= number_format($product['price'], 2); ?>
                                        </p>
                                        <div>
                                            <a href="<?= BASE_URL; ?>product/view/<?= $product['rowid']; ?>" class="btn btn-outline-primary">View Details</a>
                                            <button class="btn btn-success add-to-cart" data-product-id="<?= $product['rowid']; ?>">
                                                <i class="fas fa-cart-plus"></i> Add to Cart
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    No products found in this category. Please try different filters or check back later.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Grid/List view toggle
    const gridBtn = document.querySelector('.view-grid');
    const listBtn = document.querySelector('.view-list');
    const productsGrid = document.querySelector('.products-grid');
    const productsList = document.querySelector('.products-list');
    
    if (gridBtn && listBtn) {
        gridBtn.addEventListener('click', function() {
            gridBtn.classList.add('active');
            listBtn.classList.remove('active');
            productsGrid.classList.remove('d-none');
            productsList.classList.add('d-none');
        });
        
        listBtn.addEventListener('click', function() {
            listBtn.classList.add('active');
            gridBtn.classList.remove('active');
            productsList.classList.remove('d-none');
            productsGrid.classList.add('d-none');
        });
    }
    
    // Add to cart functionality
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.getAttribute('data-product-id');
            
            // AJAX request to add product to cart
            fetch(BASE_URL + 'cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'product_id=' + productId + '&quantity=1'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Product added to cart!');
                    // Update cart count if needed
                } else {
                    alert(data.message || 'Failed to add product to cart');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
    });
});
</script>

<?php require_once 'app/views/containers/footer.php'; ?>