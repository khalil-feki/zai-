<?php require_once 'app/views/containers/header.php'; ?>

<div class="order-detail-container">
    <div class="order-detail-header">
        <h1>Order #<?= htmlspecialchars($order['ref']) ?></h1>
        <a href="<?= BASE_URL ?>orders" class="btn btn-secondary">Back to Orders</a>
    </div>
    
    <div class="order-detail-content">
        <div class="order-info-section">
            <div class="order-info-card">
                <h3>Order Information</h3>
                <div class="order-info-details">
                    <p><strong>Order Date:</strong> <?= date('F j, Y', strtotime($order['date_creation'])) ?></p>
                    <p><strong>Status:</strong> 
                        <?php
                        $statusClass = '';
                        $statusText = '';
                        switch ($order['fk_statut']) {
                            case 0:
                                $statusClass = 'status-draft';
                                $statusText = 'Draft';
                                break;
                            case 1:
                                $statusClass = 'status-validated';
                                $statusText = 'Validated';
                                break;
                            case 2:
                                $statusClass = 'status-processing';
                                $statusText = 'Processing';
                                break;
                            case 3:
                                $statusClass = 'status-shipped';
                                $statusText = 'Shipped';
                                break;
                            case 4:
                                $statusClass = 'status-delivered';
                                $statusText = 'Delivered';
                                break;
                            case -1:
                                $statusClass = 'status-cancelled';
                                $statusText = 'Cancelled';
                                break;
                            default:
                                $statusClass = 'status-unknown';
                                $statusText = 'Unknown';
                        }
                        ?>
                        <span class="status-badge <?= $statusClass ?>"><?= $statusText ?></span>
                    </p>
                    <p><strong>Total:</strong> $<?= number_format($order['total_ttc'], 2) ?></p>
                </div>
            </div>
            
            <?php if (!empty($order['note_private'])): ?>
            <div class="order-info-card">
                <h3>Shipping Address</h3>
                <div class="order-address">
                    <p><?= nl2br(htmlspecialchars($order['note_private'])) ?></p>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="order-items-section">
            <h3>Order Items</h3>
            <div class="order-items-table">
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orderItems as $item): ?>
                            <tr>
                                <td>
                                    <div class="product-info">
                                        <?php if (!empty($item['image_url'])): ?>
                                            <img src="<?= BASE_URL . htmlspecialchars($item['image_url']) ?>" alt="<?= htmlspecialchars($item['product_name']) ?>" class="product-thumbnail" onerror="this.src='<?= BASE_URL ?>public/images/no-image.jpg'">
                                        <?php endif; ?>
                                        <div class="product-details">
                                            <a href="<?= BASE_URL ?>products/view/<?= $item['fk_product'] ?>"><?= htmlspecialchars($item['product_name'] ?? $item['description']) ?></a>
                                        </div>
                                    </div>
                                </td>
                                <td>$<?= number_format($item['price'], 2) ?></td>
                                <td><?= $item['qty'] ?></td>
                                <td>$<?= number_format($item['total_ht'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-right"><strong>Subtotal:</strong></td>
                            <td>$<?= number_format($order['total_ht'], 2) ?></td>
                        </tr>
                        <?php if (isset($order['total_tva']) && $order['total_tva'] > 0): ?>
                        <tr>
                            <td colspan="3" class="text-right"><strong>Tax:</strong></td>
                            <td>$<?= number_format($order['total_tva'], 2) ?></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td colspan="3" class="text-right"><strong>Total:</strong></td>
                            <td><strong>$<?= number_format($order['total_ttc'], 2) ?></strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'app/views/containers/footer.php'; ?>