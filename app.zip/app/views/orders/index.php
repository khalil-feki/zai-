<?php require_once 'app/views/containers/header.php'; ?>



<div class="orders-container">
    <h1>My Orders</h1>
    
    <?php if (empty($orders)): ?>
        <div class="empty-orders">
            <p>You don't have any orders yet.</p>
            <a href="<?= BASE_URL ?>products" class="btn btn-primary">Start Shopping</a>
        </div>
    <?php else: ?>
        <div class="orders-list">
            <?php foreach ($orders as $order): ?>
                <div class="order-card">
                    <div class="order-header">
                        <div class="order-info">
                            <h3>Order #<?= htmlspecialchars($order['ref']) ?></h3>
                            <p class="order-date">Placed on <?= date('F j, Y', strtotime($order['date_creation'])) ?></p>
                        </div>
                        <div class="order-status">
                            <?php
                            $statusClass = '';
                            $statusText = '';
                            switch ($order['fk_statut']) {
                                case 0:
                                    $statusClass = 'status-draft';
                                    $statusText = 'Draft';
                                    break;
                                case 1:
                                    $statusClass = 'status-validated';
                                    $statusText = 'Validated';
                                    break;
                                case 2:
                                    $statusClass = 'status-processing';
                                    $statusText = 'Processing';
                                    break;
                                case 3:
                                    $statusClass = 'status-shipped';
                                    $statusText = 'Shipped';
                                    break;
                                case 4:
                                    $statusClass = 'status-delivered';
                                    $statusText = 'Delivered';
                                    break;
                                case -1:
                                    $statusClass = 'status-cancelled';
                                    $statusText = 'Cancelled';
                                    break;
                                default:
                                    $statusClass = 'status-unknown';
                                    $statusText = 'Unknown';
                            }
                            ?>
                            <span class="status-badge <?= $statusClass ?>"><?= $statusText ?></span>
                        </div>
                    </div>
                    <div class="order-details">
                        <div class="order-total">
                            <p>Total: $<?= number_format($order['total_ttc'], 2) ?></p>
                        </div>
                        <div class="order-actions">
                            <a href="<?= BASE_URL ?>orders/view/<?= $order['rowid'] ?>" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'app/views/containers/footer.php'; ?>