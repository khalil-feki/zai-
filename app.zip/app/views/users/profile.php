<?php require_once 'app/views/containers/header.php'; ?>

<div class="profile-container">
    <div class="profile-header">
        <h1>My Profile</h1>
    </div>
    
    <div class="profile-content">
        <div class="profile-sidebar">
            <div class="profile-avatar">
                <img src="<?= BASE_URL ?>public/images/avatar.png" alt="Profile Avatar">
                <h3><?= htmlspecialchars(($user['firstname'] ?? '') . ' ' . ($user['lastname'] ?? '')) ?></h3>
                <p class="user-email"><?= htmlspecialchars($user['email'] ?? 'No email available') ?></p>
            </div>
            
            <div class="profile-menu">
                <ul>
                    <li class="active"><a href="<?= BASE_URL ?>user/profile">Profile Information</a></li>
                    <li><a href="<?= BASE_URL ?>user/orders">My Orders</a></li>
                    <li><a href="<?= BASE_URL ?>user/addresses">My Addresses</a></li>
                    <li><a href="<?= BASE_URL ?>auth/logout">Logout</a></li>
                </ul>
            </div>
        </div>
        
        <div class="profile-main">
            <div class="profile-section">
                <h2>Profile Information</h2>
                
                <?php if (isset($_SESSION['errors'])): ?>
                    <div class="alert alert-error">
                        <ul>
                            <?php foreach ($_SESSION['errors'] as $error): ?>
                                <li><?= $error ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php unset($_SESSION['errors']); ?>
                <?php endif; ?>
                
                <form action="<?= BASE_URL ?>user/update" method="POST" class="profile-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="firstname">First Name</label>
                            <input type="text" id="firstname" name="firstname" value="<?= htmlspecialchars($user['firstname'] ?? '') ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="lastname">Last Name</label>
                            <input type="text" id="lastname" name="lastname" value="<?= htmlspecialchars($user['lastname'] ?? '') ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
                    </div>
                    
                    <h3>Change Password</h3>
                    <p class="form-note">Leave blank if you don't want to change your password</p>
                    
                    <div class="form-group">
                        <label for="current_password">Current Password</label>
                        <input type="password" id="current_password" name="current_password">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input type="password" id="new_password" name="new_password">
                            <small>Minimum 6 characters</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password</label>
                            <input type="password" id="confirm_password" name="confirm_password">
                        </div>
                    </div>
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success">
                            <?= $_SESSION['success'] ?>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-error">
                            <?= $_SESSION['error'] ?>
                        </div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Update Profile</button>
                    </div>
                </form>
            </div>
            
            <div class="profile-section">
                <h2>Recent Orders</h2>
                
                <?php if (!empty($orders)): ?>
                    <div class="orders-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Total</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td><?= $order['id'] ?></td>
                                        <td><?= date('M d, Y', strtotime($order['date_created'])) ?></td>
                                        <td><span class="order-status status-<?= strtolower($order['status']) ?>"><?= $order['status'] ?></span></td>
                                        <td>$<?= number_format($order['total'], 2) ?></td>
                                        <td><a href="<?= BASE_URL ?>orders/view/<?= $order['id'] ?>" class="btn btn-sm">View</a></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-orders">
                        <p>You haven't placed any orders yet.</p>
                        <a href="<?= BASE_URL ?>products" class="btn btn-primary">Start Shopping</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'app/views/containers/footer.php'; ?>