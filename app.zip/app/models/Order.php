<?php
require_once 'app/config/database.php';
require_once 'BaseModel.php';

class Order extends BaseModel {
    protected $table = 'h8pd_commande'; // Using Dolibarr table name with prefix
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * Get orders for a specific user
     * @param int $userId User ID
     * @return PDOStatement Statement with orders
     */
    public function getUserOrders($userId) {
        try {
            $query = "SELECT * FROM {$this->table} WHERE fk_user_author = :user_id ORDER BY date_creation DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt;
        } catch (Exception $e) {
            error_log("Error getting user orders: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get order details
     * @param int $orderId Order ID
     * @param int $userId User ID
     * @return PDOStatement Statement with order details
     */
    public function getOrderDetails($orderId, $userId) {
        try {
            $query = "SELECT * FROM {$this->table} WHERE rowid = :id AND fk_user_author = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $orderId, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt;
        } catch (Exception $e) {
            error_log("Error getting order details: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get order items
     * @param int $orderId Order ID
     * @return array Array of order items
     */
    public function getOrderItems($orderId) {
        try {
            $query = "SELECT cd.*, p.label as product_name, p.price, p.ref as product_ref, 
                      CONCAT('public/images/products/', p.rowid, '.jpg') as image_url
                      FROM llx_commandedet cd
                      LEFT JOIN llx_product p ON cd.fk_product = p.rowid
                      WHERE cd.fk_commande = :order_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':order_id', $orderId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting order items: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Create a new order
     * @param int $userId User ID
     * @param array $items Cart items
     * @param array $address Shipping address
     * @return int|bool Order ID on success, false on failure
     */
    public function createOrder($userId, $items, $address) {
        try {
            // Start transaction
            $this->conn->beginTransaction();
            
            // Calculate totals
            $totalHt = 0;
            foreach ($items as $item) {
                $totalHt += $item['price'] * $item['quantity'];
            }
            
            // Apply tax rate (20%)
            $taxRate = 0.20;
            $totalTva = $totalHt * $taxRate;
            $totalTtc = $totalHt + $totalTva;
            
            // Generate order reference
            $ref = 'ORD-' . date('YmdHis') . '-' . $userId;
            
            // Insert order
            $query = "INSERT INTO {$this->table} (ref, fk_user_author, date_creation, total_ht, total_tva, total_ttc, note_private, fk_statut) 
                      VALUES (:ref, :user_id, NOW(), :total_ht, :total_tva, :total_ttc, :note_private, 0)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':ref', $ref);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':total_ht', $totalHt);
            $stmt->bindParam(':total_tva', $totalTva);
            $stmt->bindParam(':total_ttc', $totalTtc);
            $stmt->bindParam(':note_private', $address);
            $stmt->execute();
            
            $orderId = $this->conn->lastInsertId();
            
            // Insert order items
            foreach ($items as $item) {
                $query = "INSERT INTO llx_commandedet (fk_commande, fk_product, qty, price, total_ht, description) 
                          VALUES (:order_id, :product_id, :qty, :price, :total_ht, :description)";
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(':order_id', $orderId, PDO::PARAM_INT);
                $stmt->bindParam(':product_id', $item['product_id'], PDO::PARAM_INT);
                $stmt->bindParam(':qty', $item['quantity'], PDO::PARAM_INT);
                $stmt->bindParam(':price', $item['price']);
                $totalItemHt = $item['price'] * $item['quantity'];
                $stmt->bindParam(':total_ht', $totalItemHt);
                $stmt->bindParam(':description', $item['name']);
                $stmt->execute();
            }
            
            // Commit transaction
            $this->conn->commit();
            
            return $orderId;
        } catch (Exception $e) {
            // Rollback transaction on error
            $this->conn->rollBack();
            error_log("Error creating order: " . $e->getMessage());
            return false;
        }
    }
}
?>