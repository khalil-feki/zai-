<?php
require_once 'BaseModel.php';
require_once 'Product.php';

class Cart extends BaseModel {
    protected $table = 'h8pd_cart'; // Update to use the correct table prefix
    
    public function __construct() {
        parent::__construct();
        
        // Check if the cart table exists, if not create it
        if (!$this->tableExists()) {
            $this->createCartTable();
        }
    }
    
    /**
     * Add a product to the cart
     * @param int $userId User ID
     * @param int $productId Product ID
     * @param int $quantity Quantity to add
     * @return bool True on success, false on failure
     */
    public function addToCart($userId, $productId, $quantity = 1) {
        try {
            error_log("Adding to cart: User ID: $userId, Product ID: $productId, Quantity: $quantity");
            
            // Get product details
            $product = new Product();
            $productDetails = $product->findById($productId);
            
            if (!$productDetails) {
                error_log("Product not found: $productId");
                return false;
            }
            
            // Check if product already in cart
            $query = "SELECT * FROM {$this->table} WHERE fk_user = :user_id AND fk_product = :product_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                // Update quantity
                $cartItem = $stmt->fetch();
                $newQuantity = $cartItem['quantity'] + $quantity;
                
                $query = "UPDATE {$this->table} SET quantity = :quantity WHERE rowid = :id";
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(':quantity', $newQuantity, PDO::PARAM_INT);
                $stmt->bindParam(':id', $cartItem['rowid'], PDO::PARAM_INT);
            } else {
                // Insert new cart item
                $query = "INSERT INTO {$this->table} (fk_user, fk_product, quantity, price, datec) 
                          VALUES (:user_id, :product_id, :quantity, :price, NOW())";
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
                $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
                $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
                $stmt->bindParam(':price', $productDetails['price']);
            }
            
            $result = $stmt->execute();
            error_log("Add to cart result: " . ($result ? "Success" : "Failed"));
            return $result;
        } catch (Exception $e) {
            error_log("Error adding to cart: " . $e->getMessage());
            return false;
        }
    }
    
    // Create cart table if it doesn't exist
    private function createCartTable() {
        try {
            $this->conn->exec("CREATE TABLE IF NOT EXISTS {$this->table} (
                rowid INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                fk_user INT(11) NOT NULL,
                fk_product INT(11) NOT NULL,
                quantity INT(11) NOT NULL DEFAULT 1,
                price DECIMAL(10,2) NOT NULL,
                datec DATETIME NOT NULL,
                INDEX (fk_user),
                INDEX (fk_product)
            ) ENGINE=InnoDB");
            return true;
        } catch (Exception $e) {
            error_log("Error creating cart table: " . $e->getMessage());
            return false;
        }
    }
    public function getCartItems($userId) {
        $query = "SELECT c.*, p.label, p.price, p.price * c.quantity as total_price 
                  FROM " . $this->table . " c
                  JOIN h8pd_product p ON c.fk_product = p.rowid
                  WHERE c.fk_user = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        return $stmt;
    }
    /**
     * Update cart item quantity
     * @param int $cartId Cart item ID
     * @param int $userId User ID (for security check)
     * @param int $quantity New quantity
     * @return bool True on success, false on failure
     */
    public function updateCartItem($cartId, $userId, $quantity) {
        try {
            // Validate inputs
            $cartId = intval($cartId);
            $userId = intval($userId);
            $quantity = intval($quantity);
            
            if ($cartId <= 0 || $userId <= 0 || $quantity <= 0) {
                return false;
            }
            
            // Update cart item - changed 'id' to 'rowid' to match table structure
            $query = "UPDATE {$this->table} SET quantity = :quantity 
                      WHERE rowid = :cart_id AND fk_user = :user_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
            $stmt->bindParam(':cart_id', $cartId, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            
            return $stmt->execute();
        } catch (Exception $e) {
            error_log("Error updating cart item: " . $e->getMessage());
            return false;
        }
    }
    public function updateQuantity($userId, $productId, $quantity) {
        $query = "UPDATE " . $this->table . " 
                  SET quantity = :quantity 
                  WHERE fk_user = :user_id AND fk_product = :product_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':product_id', $productId);
        $stmt->bindParam(':quantity', $quantity);
        
        return $stmt->execute();
    }
    
    public function removeFromCart($userId, $productId) {
        $query = "DELETE FROM " . $this->table . " 
                  WHERE fk_user = :user_id AND fk_product = :product_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':product_id', $productId);
        
        return $stmt->execute();
    }
    
    public function clearCart($userId) {
        $query = "DELETE FROM " . $this->table . " WHERE fk_user = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        
        return $stmt->execute();
    }
    public function getCartTotal($userId) {
        $query = "SELECT SUM(p.price * c.quantity) as total 
                  FROM " . $this->table . " c
                  JOIN h8pd_product p ON c.fk_product = p.rowid
                  WHERE c.fk_user = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] ?? 0;
    }
    
    public function getCartCount($userId) {
        $query = "SELECT COUNT(*) as count FROM " . $this->table . " WHERE fk_user = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['count'] ?? 0;
    }
    
    public function getCartItemCount($userId) {
        $query = "SELECT SUM(quantity) as total_items FROM " . $this->table . " WHERE fk_user = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total_items'] ?? 0;
    }
}
?>