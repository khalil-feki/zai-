<?php
require_once 'app/models/Product.php';

class CartController {
    private $product;
    
    public function __construct() {
        $this->product = new Product();
        
        // Initialize cart session if it doesn't exist
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
    }
    
    /**
     * Add a product to the cart
     */
    public function addToCart() {
        // Check if product ID is provided
        if (!isset($_POST['product_id']) || empty($_POST['product_id'])) {
            $this->setFlashMessage('error', 'Product ID is required');
            header('Location: index.php');
            exit;
        }
        
        $productId = (int)$_POST['product_id'];
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        
        // Validate quantity
        if ($quantity <= 0) {
            $quantity = 1;
        }
        
        // Check if product is available for sale
        if (!$this->product->isAvailableForSale($productId)) {
            $this->setFlashMessage('error', 'This product is not available for sale');
            header('Location: index.php');
            exit;
        }
        
        // Get product details
        $product = $this->product->getForCart($productId);
        
        if (!$product) {
            $this->setFlashMessage('error', 'Product not found');
            header('Location: index.php');
            exit;
        }
        
        // Check if product already exists in cart
        $found = false;
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['rowid'] == $productId) {
                $item['quantity'] += $quantity;
                $item['total_price'] = $item['price'] * $item['quantity'];
                $found = true;
                break;
            }
        }
        
        // If product not in cart, add it
        if (!$found) {
            $product['quantity'] = $quantity;
            $product['total_price'] = $product['price'] * $quantity;
            $_SESSION['cart'][] = $product;
        }
        
        $this->setFlashMessage('success', 'Product added to cart');
        header('Location: index.php?page=cart');
        exit;
    }
    
    /**
     * View cart contents
     */
    public function viewCart() {
        // Get cart items from session
        $cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
        
        // Calculate total price
        $totalPrice = 0;
        foreach ($cart as $item) {
            $totalPrice += $item['total_price'];
        }
        
        // Include the view
        require_once 'app/views/containers/header.php';
        require_once 'app/views/cart/view.php';
        require_once 'app/views/containers/footer.php';
    }
    
    /**
     * Update cart item quantity
     */
    public function updateCart() {
        if (!isset($_POST['product_id']) || !isset($_POST['quantity'])) {
            $this->setFlashMessage('error', 'Invalid request');
            redirect('?page=cart');
            return;
        }
        
        $productId = (int)$_POST['product_id'];
        $quantity = (int)$_POST['quantity'];
        
        // Remove item if quantity is 0
        if ($quantity <= 0) {
            foreach ($_SESSION['cart'] as $key => $item) {
                if ($item['rowid'] == $productId) {
                    unset($_SESSION['cart'][$key]);
                    break;
                }
            }
            
            // Reindex array
            $_SESSION['cart'] = array_values($_SESSION['cart']);
            
            $this->setFlashMessage('success', 'Item removed from cart');
            redirect('?page=cart');
            exit;
        }
        
        // Update quantity
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['rowid'] == $productId) {
                $item['quantity'] = $quantity;
                $item['total_price'] = $item['price'] * $quantity;
                break;
            }
        }
        
        // After successful update
        $this->setFlashMessage('success', 'Cart updated successfully');
        redirect('?page=cart');
    }
    
    /**
     * Remove item from cart
     */
    public function removeFromCart() {
        if (!isset($_GET['id'])) {
            $this->setFlashMessage('error', 'Invalid request');
            header('Location: index.php?page=cart');
            exit;
        }
        
        $productId = (int)$_GET['id'];
        
        foreach ($_SESSION['cart'] as $key => $item) {
            if ($item['rowid'] == $productId) {
                unset($_SESSION['cart'][$key]);
                break;
            }
        }
        
        // Reindex array
        $_SESSION['cart'] = array_values($_SESSION['cart']);
        
        $this->setFlashMessage('success', 'Item removed from cart');
        redirect('?page=cart');
    }
    
    /**
     * Clear cart
     */
    public function clearCart() {
        // Clear the cart
        $_SESSION['cart'] = [];
        
        // Set flash message
        $_SESSION['flash'] = [
            'type' => 'success',
            'message' => 'Your cart has been cleared.'
        ];
        
        // Redirect to cart view
        header('Location: index.php?page=cart');
        exit;
    }
    
    /**
     * Set flash message
     */
    private function setFlashMessage($type, $message) {
        $_SESSION['flash'] = [
            'type' => $type,
            'message' => $message
        ];
    }
}
?>