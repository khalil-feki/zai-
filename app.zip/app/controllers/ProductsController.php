<?php
require_once 'app/models/Product.php';
require_once 'app/services/DolibarrService.php';

class ProductsController {
    private $productModel;
    
    public function __construct() {
        $this->productModel = new Product();
    }
    
    /**
     * Display product listing with optional filtering
     */
    public function index() {
        // Get pagination parameters
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 12; // Products per page
        $offset = ($page - 1) * $limit;
        
        // Get search parameters
        $search = isset($_GET['search']) ? trim($_GET['search']) : null;
        
        // Only show products that are for sale
        $this->productModel->setTosellFilter(true);
        
        // Get products with pagination
        $products = $this->productModel->findAll($limit, $offset, $search);
        
        // Get total product count for pagination
        $totalProducts = $this->productModel->count();
        $totalPages = ceil($totalProducts / $limit);
        
        // Get price range for filters
        $minPrice = $this->productModel->min('price');
        $maxPrice = $this->productModel->max('price');
        
        // Load view
        require_once 'app/views/products/index.php';
    }
    
    /**
     * Display single product details
     */
    public function show($id) {
        // Load the product model
        require_once 'app/models/Product.php';
        $productModel = new Product();
        
        // Get product details
        $product = $productModel->findById($id);
        
        if (!$product) {
            // Product not found, redirect to products page
            header('Location: index.php?page=products');
            exit;
        }
        
        // Get similar products
        $similarProducts = $productModel->findSimilarProducts($id, 4);
        
        // Include the view
        require_once 'app/views/containers/header.php';
        require_once 'app/views/products/show.php';
        require_once 'app/views/containers/footer.php';
    }
    
    /**
     * Search products with advanced filtering
     */
    public function search() {
        // Get search parameters
        $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
        $minPrice = isset($_GET['min_price']) ? (float)$_GET['min_price'] : '';
        $maxPrice = isset($_GET['max_price']) ? (float)$_GET['max_price'] : '';
        
        // Get pagination parameters
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 12; // Products per page
        $offset = ($page - 1) * $limit;
        
        // Only show products that are for sale
        $this->productModel->setTosellFilter(true);
        
        // Search products
        $products = $this->productModel->search($keyword, null, $minPrice, $maxPrice, $limit, $offset);
        
        // Get price range for filters
        $minPriceAvailable = $this->productModel->min('price');
        $maxPriceAvailable = $this->productModel->max('price');
        
        // Load view
        require_once 'app/views/products/search.php';
    }
}?>
