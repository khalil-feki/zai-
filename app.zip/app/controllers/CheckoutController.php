<?php
require_once 'app/models/Cart.php';
require_once 'app/models/Order.php';
require_once 'app/middleware/AuthMiddleware.php';

class CheckoutController {
    private $cartModel;
    private $orderModel;
    
    public function __construct() {
        // Check if user is logged in
        $authMiddleware = new AuthMiddleware();
        $authMiddleware->handle();
        
        $this->cartModel = new Cart();
        $this->orderModel = new Order();
    }
    
    public function index() {
        $userId = $_SESSION['user_id'];
        
        // Get cart items
        $cartItems = $this->cartModel->getCartItems($userId);
        
        // Check if cart is empty
        if ($cartItems->rowCount() === 0) {
            $_SESSION['error'] = 'Your cart is empty';
            redirect('cart');
        }
        
        // Calculate cart total
        $cartTotal = $this->cartModel->getCartTotal($userId);
        
        // Load checkout view
        require_once 'app/views/checkout/index.php';
    }
    
    public function process() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userId = $_SESSION['user_id'];
            
            // Get cart items
            $cartItemsStmt = $this->cartModel->getCartItems($userId);
            $cartItems = $cartItemsStmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Check if cart is empty
            if (empty($cartItems)) {
                $_SESSION['error'] = 'Your cart is empty';
                redirect('cart');
            }
            
            // Get form data
            $shippingAddress = $_POST['shipping_address'] ?? '';
            $billingAddress = $_POST['billing_address'] ?? '';
            
            // Validate form data
            if (empty($shippingAddress)) {
                $_SESSION['error'] = 'Shipping address is required';
                redirect('checkout');
            }
            
            try {
                // Create order
                $orderId = $this->orderModel->createOrder($userId, $cartItems, $shippingAddress, $billingAddress);
                
                if ($orderId) {
                    // Clear cart after successful order
                    $this->cartModel->clearCart($userId);
                    
                    $_SESSION['success'] = 'Order placed successfully!';
                    redirect('?page=user&action=orders');
                } else {
                    $_SESSION['error'] = 'Failed to place order';
                    redirect('checkout');
                }
            } catch (Exception $e) {
                $_SESSION['error'] = 'An error occurred: ' . $e->getMessage();
                redirect('checkout');
            }
        } else {
            // Redirect to checkout page if not POST request
            redirect('checkout');
        }
    }
    
    public function success($orderId) {
        $userId = $_SESSION['user_id'];
        
        // Get order details
        $orderStmt = $this->orderModel->getOrderDetails($orderId, $userId);
        
        if ($orderStmt->rowCount() === 0) {
            $_SESSION['error'] = 'Order not found';
            redirect('');
        }
        
        $order = $orderStmt->fetch(PDO::FETCH_ASSOC);
        
        // Get order items
        $orderItems = $this->orderModel->getOrderItems($orderId);
        
        // Load success view
        require_once 'app/views/checkout/success.php';
    }
}
?>